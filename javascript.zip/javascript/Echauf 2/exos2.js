var question1 = prompt ("Quelle est la couleur du cheval blanc de Henri 4?");
var question2 = prompt ("Combien y-a-t-il de 7 nains?");
