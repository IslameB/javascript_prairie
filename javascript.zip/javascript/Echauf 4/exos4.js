var nombre1 = Math.floor(Math.random () *10);
var nombre2 = Math.floor(Math.random() *10);
var operation = Math.floor(Math.random()*3);
var reponse , total;
switch (operation) {
  case 0:
      total = nombre1 * nombre2;
      reponse = prompt ("Combien font " + nombre1 + " * " + nombre2 + " ? " );
      break;
  case 1:
      total = nombre1 + nombre2;
      reponse = prompt ("Calculez " + nombre1 + " + " + nombre2 + " ? " );
      break;
  case 2:
      total = nombre1 - nombre2;
      reponse = prompt ("Faites la différence entre " + nombre1 + " et "  + nombre2);
      break;
  }
  if (reponse==total) {
    alert ("Bravo ! ");
    }
  else {
    alert ("Essayez de nouveau ! ");

  }
