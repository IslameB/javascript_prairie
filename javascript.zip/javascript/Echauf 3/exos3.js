var identifiant = prompt ("Identifiant");
var mot_de_passe = prompt ("Mot de passe");
if (identifiant.length <4 || identifiant.search == "@"){
  alert("Erreur");
}
else if (identifiant=="lea@gmail.com" && mot_de_passe=="12345") {
 alert("Bienvenue !");
}
else {
  alert("Erreur");
}
