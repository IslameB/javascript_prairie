var notes;
var moyenne = 0;
for(var i = 0; i < 10; i++){
  notes = parseInt(prompt("Saisir vos 10 notes :"));
  if(notes >= 0 && notes <= 20){
    moyenne = moyenne + notes;
  }
  else {
    alert("Erreur");
  }
}
"moyenne/10";
alert("Votre moyenne est de" + moyenne);
