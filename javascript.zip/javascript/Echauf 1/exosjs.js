var nom = prompt("Comment t'appelles-tu?");
if (nom == ""){
  alert("Erreur");
  }
else if (nom.length <1 && nom.length>10) {
  alert("Erreur");
  }
else {
  alert("Bonjour " + nom + " !");
}
